import UIKit

// if 문

let age = 7

if age < 3 {
    print("baby")
}else if age>=3 && age < 20 {
    print("child")
}else {
    print("Adult")
}



// switch 문

switch age {
case 0,1,2:
    print("baby")
case 3...20:
    print("child")
default:
    print("adult")
}
